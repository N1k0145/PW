
<!DOCTYPE html>
<html>
<head><title>Menu Produto</title></head>
<body>
    <h1>Menu de Produtos</h1>
    <ul>
        <li><a href='listarProdutos.php'>Listar Produtos</a></li>
    </ul>
</body>
</html>
