
<?php
include 'conexao.php';
$stmt = $conn->prepare("SELECT * FROM produto");
$stmt->execute();
$produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head><title>Listar Produtos</title></head>
<body>
    <h1>Produtos Escolares</h1>
    <table border="1">
        <tr><th>ID</th><th>Nome</th><th>Preço</th><th>Quantidade</th></tr>
        <?php foreach ($produtos as $p): ?>
        <tr>
            <td><?= $p['id'] ?></td>
            <td><?= $p['nome'] ?></td>
            <td><?= number_format($p['preco'], 2, ',', '.') ?></td>
            <td><?= $p['quantidade'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
