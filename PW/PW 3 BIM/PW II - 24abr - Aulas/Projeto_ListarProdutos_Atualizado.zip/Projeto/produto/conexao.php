
<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "exemplocurso";

try {
    $conn = new PDO("mysql:host=$host", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->exec("CREATE DATABASE IF NOT EXISTS $dbname");
    $conn->exec("USE $dbname");
    $conn->exec("
        CREATE TABLE IF NOT EXISTS produto (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(100),
            preco DECIMAL(10,2),
            quantidade INT
        )
    ");
    $check = $conn->query("SELECT COUNT(*) FROM produto")->fetchColumn();
    if ($check == 0) {
        $conn->exec("
            INSERT INTO produto (nome, preco, quantidade) VALUES
            ('Caderno', 15.00, 100),
            ('Lápis', 1.50, 500),
            ('Borracha', 2.00, 300),
            ('Régua', 3.50, 150),
            ('Caneta', 2.20, 400),
            ('Estojo', 12.00, 80),
            ('Cola', 4.00, 120),
            ('Tesoura', 6.50, 90),
            ('Apontador', 1.80, 200),
            ('Mochila', 45.00, 60)
        ");
    }
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
    die();
}
?>
